# src/model_api/main.py
from __future__ import annotations
import os, json, time
from pathlib import Path
from typing import Any, Dict, List
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# IMPORTANT: use absolute imports from the src package
from src.model_api.util_explain import Explainer, featurize
from src.model_api.policy import Policy

import re
IP_RE = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')

def autoparse_into_data(alert: dict) -> None:
    """
    Best-effort parser: extract IPs from full_log and seed data/rule
    so the feature vector isn't mostly zeros.
    """
    data = alert.setdefault("data", {})
    flog = alert.get("full_log", "") or ""

    ips = IP_RE.findall(flog)
    if "srcip" not in data and ips:
        data["srcip"] = ips[0]
    if "dstip" not in data and len(ips) > 1:
        data["dstip"] = ips[1]

    # Sensible defaults for AP/syslog messages
    data.setdefault("service", "AP")
    data.setdefault("proto", "udp")
    data.setdefault("dstport", 514)

    # Ensure we have a rule so rule_level isn't zero-by-structure
    alert.setdefault("rule", {"id": 999001, "level": 2, "description": "Autoparsed AP/syslog"})

HERE = Path(__file__).parent
OUT_DIR = HERE.parent / "out"
OUT_DIR.mkdir(parents=True, exist_ok=True)

MODEL_PATH  = os.environ.get("MODEL_PATH")  or str(HERE / "model.joblib")
POLICY_PATH = os.environ.get("POLICY_PATH") or str(HERE / "policy.yaml")
TOP_K       = int(os.environ.get("TOP_K_FEATURES", "8"))

print(f"[XAI] MODEL_PATH={MODEL_PATH}")
print(f"[XAI] POLICY_PATH={POLICY_PATH}")
print(f"[XAI] OUT_DIR={OUT_DIR}")

policy    = Policy(POLICY_PATH)
explainer = Explainer(model_path=MODEL_PATH, top_k=TOP_K)

app = FastAPI(title="Explainable SOC API", version="1.0")

# optional simple static UI folder if you have one (safe even if missing)
static_dir = HERE / "ui"
if static_dir.exists():
    app.mount("/ui", StaticFiles(directory=str(static_dir), html=True), name="ui")

class ScoreExplainIn(BaseModel):
    alert_id: str
    alert: Dict[str, Any]

@app.post("/score_explain")
def score_explain(body: ScoreExplainIn):
    # 1) Work on a copy, enrich it, and then use THIS object everywhere
    alert = dict(body.alert)
    autoparse_into_data(alert)  # fill data/rule from full_log if missing

    # 2) Score + explain the ENRICHED alert
    try:
        proba, top_features, used_mask = explainer.score_and_explain(alert)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Explain error: {e}")

    # 3) Policy on the ENRICHED alert (so rules can use seeded fields)
    feature_names = explainer.feature_names
    pol = policy.decide(
        score=proba,
        alert=alert,                  # <<< use enriched alert
        used_mask=used_mask,
        feature_names=feature_names,
        model_path=MODEL_PATH
    )

    # 4) (Optional) quick debug: list a few missing features
    missing = [n for n, used in zip(feature_names, used_mask) if not used]

    # 5) Build response using the enriched alert
    doc = {
        "alert_id": body.alert_id,
        "@timestamp": alert.get("@timestamp") or alert.get("timestamp"),
        "model": Path(MODEL_PATH).name,
        "backend": "shap",
        "score": proba,
        "class_prob": {"neg": 1.0 - proba, "pos": proba},
        "top_features": top_features,
        "decisive_events": alert.get("evidence", []),
        **pol,
        "debug": {                          # <- remove later if you want
            "first_missing": missing[:10],
            "coverage_pct": pol["health"]["feature_coverage_pct"],
        },
        "raw_hash": str(abs(hash(json.dumps(alert, sort_keys=True)))),
    }

    with open(OUT_DIR / "wazuh-explain-v1.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(doc) + "\n")

    return doc

class FeedbackIn(BaseModel):
    alert_id: str
    trust_score: int   # 1..5
    overridden: bool = False
    decision_ms: int | None = None

@app.post("/feedback")
def feedback(body: FeedbackIn):
    rec = {"@timestamp": int(time.time()*1000), **body.model_dump()}
    with open(OUT_DIR / "wazuh-explain-feedback-v1.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    return {"ok": True}
