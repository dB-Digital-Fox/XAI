# src/model_api/util_explain.py
from __future__ import annotations
import os, json
from typing import Dict, Any, List, Tuple
import numpy as np
from joblib import load
import shap
import hashlib as _hl

# ------------------ featurizer helpers (match training) ------------------
def dig(d: Dict, path: str, default=None):
    cur = d
    for p in path.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

def _hash_to_int(val, mod=100000):
    if val is None: return 0
    h = _hl.blake2b(str(val).encode("utf-8"), digest_size=4).hexdigest()
    return int(h, 16) % mod

def num_or_hash(val, mod=100000) -> float:
    if val is None: return 0.0
    if isinstance(val, (int, float)): return float(val)
    s = str(val)
    try: return float(s)
    except: return float(_hash_to_int(s, mod=mod))

def featurize(alert: Dict[str,Any]) -> Dict[str,float]:
    f = {}
    f["rule_level"]        = num_or_hash(dig(alert,"rule.level",0))
    f["rule_id_hash"]      = float(_hash_to_int(dig(alert,"rule.id","")))
    f["src_port"]          = num_or_hash(dig(alert,"data.srcport",0))
    f["dst_port"]          = num_or_hash(dig(alert,"data.dstport",0))
    f["proto_num"]         = num_or_hash(dig(alert,"data.proto",0))
    f["service_hash"]      = float(_hash_to_int(dig(alert,"data.service","")))
    f["app_hash"]          = float(_hash_to_int(dig(alert,"data.app","")))
    f["appcat_hash"]       = float(_hash_to_int(dig(alert,"data.appcat","")))
    f["apprisk_hash"]      = float(_hash_to_int(dig(alert,"data.apprisk","")))
    f["action_hash"]       = float(_hash_to_int(dig(alert,"data.action","")))
    f["srccountry_hash"]   = float(_hash_to_int(dig(alert,"data.srccountry","")))
    f["dstcountry_hash"]   = float(_hash_to_int(dig(alert,"data.dstcountry","")))
    f["eventtime_num"]     = num_or_hash(dig(alert,"data.eventtime",0))
    f["win_event_id"]      = num_or_hash(dig(alert,"data.win.system.eventID",0))
    f["win_logon_type"]    = num_or_hash(dig(alert,"data.win.eventdata.logonType",0))
    f["win_severity_hash"] = float(_hash_to_int(dig(alert,"data.win.system.severityValue","")))
    return f
# ------------------------------------------------------------------------

class Explainer:
    def __init__(self, model_path: str, top_k: int = 8):
        # load bundle and extract model + feature names
        bundle = load(model_path)
        if isinstance(bundle, dict) and "model" in bundle and "feature_cols" in bundle:
            self.model = bundle["model"]
            self.feature_names: List[str] = list(bundle["feature_cols"])
        else:
            # legacy: saved bare estimator
            self.model = bundle
            # best effort: try to read feature names from attribute or leave empty
            self.feature_names = getattr(self.model, "feature_names_in_", [])

        self.model_path = model_path
        self.top_k = int(top_k)

        # Prepare SHAP explainer
        self.tree_explainer = None
        try:
            # CalibratedClassifierCV -> calibrated_classifiers_[0].base_estimator
            base_est = getattr(self.model, "calibrated_classifiers_", None)
            if base_est:
                base_est = base_est[0].base_estimator
            else:
                base_est = self.model
            # Will work for tree models (RandomForest, XGBoost via sklearn wrapper, etc.)
            self.tree_explainer = shap.TreeExplainer(base_est, feature_names=self.feature_names or None)
        except Exception:
            self.tree_explainer = None  # we'll kernel-explain on demand

    def _vectorize(self, fdict: Dict[str, float]) -> np.ndarray:
        # ensure order matches training
        return np.array([fdict.get(c, 0.0) for c in self.feature_names], dtype=float)

    def score_and_explain(self, alert: Dict[str, Any]) -> Tuple[float, List[Dict[str, float]], List[bool]]:
        # 1) build features
        fdict = featurize(alert)
        x = self._vectorize(fdict)

        # 2) probability
        proba = float(self.model.predict_proba([x])[0, 1])

        # 3) SHAP values
        try:
            if self.tree_explainer is not None:
                raw = self.tree_explainer.shap_values(x)
                shap_vals = raw[1] if isinstance(raw, list) else raw  # binary case
            else:
                # model-agnostic fallback
                bg = np.tile(x, (50, 1))
                kexp = shap.KernelExplainer(lambda X: self.model.predict_proba(X)[:, 1], bg)
                shap_vals = kexp.shap_values(x, nsamples=200)
        except Exception:
            shap_vals = np.zeros_like(x)

        # 4) map to names and pick top-k
        contrib = {name: float(val) for name, val in zip(self.feature_names, shap_vals.flatten().tolist())}
        top = sorted(contrib.items(), key=lambda kv: abs(kv[1]), reverse=True)[: self.top_k]
        top_features = [{"feature": k, "contribution": v} for k, v in top]

        # 5) which features were actually present (non-zero used)
        used_mask = [bool(fdict.get(c, 0.0) != 0.0) for c in self.feature_names]

        return proba, top_features, used_mask


''' #old
from __future__ import annotations
import numpy as np, pandas as pf, shap, json, os, yaml
from lime.lime_tabular import LimeTabularExplainer
from joblib import load as joblib_load

def _get(d: dict, dotted: str, default=None):
    cur = d
    for p in dotted.split('.'):
        if not instance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur

class Explainer:
    def __init__(self, model_path: str, feature_map_path: str, backend: str = "shap", top_k: int = 8):
        self.model = joblib_load(model_path)
        self.backend = backend
        self.top_k = top_k
        with open(feature_map_path, "r", encoding="utf-8") as f:
            spec = yaml.safe_load(f)
        self.feature_defs = spec["features"]
        self.feature_names = [f["name"] for f in self.feature_defs]

        #for LIME baseline ranges
        self._means = np.zeros(len(self.feature_names))
        self._stds = np.ones(len(self.feature_names))

        #prefit SHAP
        if backend == "shap":
            try:
                self.shap_explainer = shap.Explainer(self.model)
            except Exception:
                self.shap_explainer = shap.KernelExplainer(self.model.predict_proba, shap.kmeans(np.zeros((10,len(self.feature_names))), 5))

    def xform(self, alert: dict) -> np.ndarray:
        vals = []
        for f in self.feature_defs:
            vals.append(_get(alert, f["path"], f.get("default",0)))
        return np.array(vals, dtype = float)
    
    def predict_proba(self, X: np.ndarray):
         # 2-class assumption; adjust if needed
        return self.model.predict_proba(X.reshape(1, -1))[0].tolist()
    
    def explain(self, alert: dict) -> dict:
        X = self.xform(alert)
        proba = self.predict_proba(X)
        score = float(proba[1])  #assume binary classification, adjust if needed

        if self.backend == "shap":
            sv = self.shap_explainer(X.reshape(1,-1))
            phi = sv.values[0]
            base_val = float(sv.base_values[0]) if hasattr(sv.base_values, "__len__") else 0.0
            contribs = list(zip(self.feature_names, phi))
        else:
            expl = LimeTabularExplainer(
                training_data = np.stack([self._means]*50) + np.random.randn(50, len(self._means))*self._stds,
                feature_names = self.feature_names,
                mode = "classification"
            )
            exp = expl.explain_instance(X, lambda z: self.model.predict_proba(z), num_features=min(self.top_k, len(self.feature_names)))
            contribs = exp.as_list()
            base_val = None

        #sort absolute impact
        contrib_sorted = sorted(contribs, key=lambda x: abs(float(x[1])), reverse=True)[:self.top_k]
        top_features = [{"feature": f, "contribution": float(v)} for f,v in contrib_sorted]

        #optional: extract decisive events back from alert
        decisice = []
        if "evidence" in alert:
            for ev in alert["evidence"][:5]:
                decisive.append({
                    "ts": ev.get("@timestamp"),
                    "type": ev.get("kind") or ev.get("rule", {}).get("description"),
                    "snippet": ev.get("message", "")[:240]
                })

        return {
            "model": os.path.basename(os.environ.get("MODEL_PATH","model.joblib")),
            "backend": self.backend,
            "score": score,
            "class_prob": {"neg": float(proba[0]), "pos": float(proba[1])},
            "top_features": top_features,
            "base_value": base_val,
            "decisive_events": decisive
        }
    '''